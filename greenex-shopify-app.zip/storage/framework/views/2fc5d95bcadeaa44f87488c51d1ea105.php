<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-11xl mx-auto mt-1 px-4 sm:px-6 lg:px-8">
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">

        
        <?php echo $__env->make('partials.card', [
            'icon' => '<i class="fa fa-box-open text-white text-4xl"></i>',
            'value' => $data['t_parcel'],
            'label' => 'Total Parcel'
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        
        <?php echo $__env->make('partials.card', [
            'icon' => '<i class="fa fa-shipping-fast text-white text-4xl"></i>',
            'value' => $data['t_delivered'],
            'label' => 'Total Delivered'
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        
        <?php echo $__env->make('partials.card', [
            'icon' => '<i class="fa fa-dna text-white text-4xl"></i>',
            'value' => $data['t_return'],
            'label' => 'Total Return'
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        
        <?php echo $__env->make('partials.card', [
            'icon' => '<i class="fa fa-dolly text-white text-4xl"></i>',
            'value' => $data['t_parcel'] - $data['t_delivered'] - $data['t_return'],
            'label' => 'Total Transit'
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        
        <?php echo $__env->make('partials.card', [
            'icon' => '<i class="fa fa-hand-holding-usd text-white text-4xl"></i>',
            'value' => $data['t_sale'],
            'label' => 'Total Sales Amount'
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        
        <?php echo $__env->make('partials.card', [
            'icon' => '<i class="fa fa-hands-helping text-white text-4xl"></i>',
            'value' => $data['t_delivery_fee'],
            'label' => 'Total Delivery Fees Paid'
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        
        <?php echo $__env->make('partials.card', [
            'icon' => '<i class="fa fa-dna text-white text-4xl"></i>',
            'value' => $data['t_vat_amount'],
            'label' => 'Total Vat Amount'
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        
        <?php echo $__env->make('partials.card', [
            'icon' => '<i class="fa fa-hockey-puck text-white text-4xl"></i>',
            'value' => $data['t_liquid_fragile'],
            'label' => 'Net Profit Amount'
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        
        <?php echo $__env->make('partials.card', [
            'icon' => '<i class="fa fa-credit-card text-white text-4xl"></i>',
            'value' => $data['t_balance_paid'],
            'label' => 'Current Balance'
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        
        <?php echo $__env->make('partials.card', [
            'icon' => '<i class="fa fa-donate text-white text-4xl"></i>',
            'value' => $data['t_balance_proc'],
            'label' => 'Opening Balance'
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        
        <?php echo $__env->make('partials.card', [
            'icon' => '<i class="fa fa-hourglass-half text-white text-4xl"></i>',
            'value' => $data['t_balance_proc'],
            'label' => 'Payment Processing'
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        
        <?php echo $__env->make('partials.card', [
            'icon' => '<i class="fa fa-database text-white text-4xl"></i>',
            'value' => $data['t_balance_paid'],
            'label' => 'Paid Amount'
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        
        <?php echo $__env->make('partials.card', [
            'icon' => '<i class="fa fa-home text-white text-4xl"></i>',
            'value' => $data['t_shop'],
            'label' => 'Total Shops'
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        
        <?php echo $__env->make('partials.card', [
            'icon' => '<i class="fa fa-boxes text-white text-4xl"></i>',
            'value' => $data['t_parcel_bank'],
            'label' => 'Total Parcel Bank Items'
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        
        <?php echo $__env->make('partials.card', [
            'icon' => '<i class="fa fa-history text-white text-4xl"></i>',
            'value' => $data['t_request'],
            'label' => 'Total Payment Request'
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\greenex-shopify-app\resources\views/dashboard.blade.php ENDPATH**/ ?>