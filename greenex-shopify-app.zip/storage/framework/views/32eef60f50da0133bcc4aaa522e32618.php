<?php
    $host = Request::get('host');
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopify Admin</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <script src="https://unpkg.com/@shopify/app-bridge@3"></script>
    <script>
        var AppBridge = window['app-bridge'];
        var actions = AppBridge.actions;
    </script>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body class="bg-gray-100">

    
    <?php echo $__env->make('layouts.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <main class="p-6">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <?php echo $__env->make('layouts.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Shopify App Bridge Script -->
    <script>
        // Initialize Shopify App Bridge
        var AppBridge = window['app-bridge'];
        var createApp = AppBridge.default;
        var actions = AppBridge.actions;

        // Get host parameter from URL
        var host = new URLSearchParams(window.location.search).get('host');

        if (host) {
            var app = createApp({
                apiKey: '<?php echo e(config('shopify-app.api_key')); ?>',
                host: host,
                forceRedirect: true
            });

            // Set up app bridge actions
            var TitleBar = actions.TitleBar;
            TitleBar.create(app, {
                title: '<?php echo e(config('shopify-app.app_name')); ?>'
            });
        }
    </script>
</body>

</html>
<?php /**PATH C:\laragon\www\greenex-shopify-app\resources\views/layouts/app.blade.php ENDPATH**/ ?>