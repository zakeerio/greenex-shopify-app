<?php $__env->startSection('title', 'Settings'); ?>

<?php $__env->startSection('content'); ?>
    <section class="max-w-11xl mx-auto mt-1 px-4 sm:px-6 lg:px-8">

        <form id="SettingForm" action="<?php echo e(route('authenticateAndSave')); ?>" class="p-4 md:p-5 bg-gray-200 rounded-lg shadow"
            method="POST">
            <div class="grid gap-4 mb-4 lg:grid-cols-3 md:grid-cols-2">

                <?php echo csrf_field(); ?>

                <input type="hidden" name="user_id" value="<?php echo e(auth()->user()->id); ?>">

                <div>
                    <label for="email" class="block mb-2 text-sm font-medium text-gray-900">Email</label>
                    <input type="text" id="email" name="email"
                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5"
                        placeholder="Email address" required <?php echo e($settings ? 'readonly' : ''); ?>

                        value="<?php echo e(old('email', $settings->email ?? '')); ?>">
                </div>

                <div>
                    <label for="password" class="block mb-2 text-sm font-medium text-gray-900">Password</label>
                    <input type="password" id="password" name="password" <?php echo e($settings ? 'readonly' : ''); ?>

                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5"
                        placeholder="Password">
                </div>

                <div>
                    <label for="fullfilment" class="block mb-2 text-sm font-medium text-gray-900">Fullfillment
                        Location</label>
                    <select id="fullfilment" name="fullfilment"
                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5">
                        <option value="">Fullfillment Location</option>
                        <?php $__currentLoopData = ['islamabad', 'lahore', 'faislabad', 'rawalpindi', 'karachi']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($city); ?>"
                                <?php echo e(($settings->fulfillment_location ?? '') === $city ? 'selected' : ''); ?>>
                                <?php echo e(ucfirst($city)); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div>
                    <label for="Fragile" class="block mb-2 text-sm font-medium text-gray-900">Fragile</label>
                    <select id="Fragile" name="fragile"
                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5">
                        <option value="">Fragile</option>
                        <option value="Yes" <?php echo e($settings->fragile ?? false ? 'selected' : ''); ?>>Yes</option>
                        <option value="No" <?php echo e(empty($settings->fragile) ? 'selected' : ''); ?>>No</option>
                    </select>
                </div>

                <?php
                    use Illuminate\Support\Str;

                    $apiMasked = $settings->api_token ?? '';
                    if ($apiMasked) {
                        // Mask everything except last 4 characters
                        $apiMasked = Str::mask($apiMasked, '*', 0, strlen($apiMasked) - 4);
                    }
                ?>

                <div>
                    <label for="apikey" class="block mb-2 text-sm font-medium text-gray-900">API Key</label>
                    <input type="text" id="apikey" name="apikey" <?php echo e($settings ? 'readonly' : ''); ?>

                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5"
                        placeholder="API Key" value="<?php echo e(old('apikey', $apiMasked ?? '')); ?>">
                </div>

                <div>
                    <label for="Insurance" class="block mb-2 text-sm font-medium text-gray-900">Insurance</label>
                    <select id="Insurance" name="insurance"
                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5">
                        <option value="">Insurance</option>
                        <option value="Yes" <?php echo e($settings->insurance ?? false ? 'selected' : ''); ?>>Yes</option>
                        <option value="No" <?php echo e(empty($settings->insurance) ? 'selected' : ''); ?>>No</option>
                    </select>
                </div>

                <div>
                    <label for="accounttype" class="block mb-2 text-sm font-medium text-gray-900">Account Type</label>
                    <select id="accounttype" name="account_type"
                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5">
                        <option value="">Account Type</option>
                        <option value="live" <?php echo e(($settings->account_type ?? '') === 'live' ? 'selected' : ''); ?>>Live
                        </option>
                        <option value="offline" <?php echo e(($settings->account_type ?? '') === 'offline' ? 'selected' : ''); ?>>
                            Offline</option>
                    </select>
                </div>

                <div>
                    <label for="auto_push_orders" class="block mb-2 text-sm font-medium text-gray-900">Order Push
                        Automatically on CMS</label>
                    <select id="auto_push_orders" name="auto_push_orders"
                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5">
                        <option value="">Order Push Automatically</option>
                        <option value="Yes" <?php echo e($settings->auto_push_cms ?? false ? 'selected' : ''); ?>>Yes</option>
                        <option value="No" <?php echo e(empty($settings->auto_push_cms) ? 'selected' : ''); ?>>No</option>
                    </select>
                </div>

                <div>
                    <label for="price" class="block mb-2 text-sm font-medium text-gray-900">Price</label>
                    <input type="number" id="price" name="price"
                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5"
                        placeholder="$2999" value="<?php echo e(old('price', $settings->price ?? '')); ?>">
                </div>

            </div>

            <div class="flex flex-col md:flex-row md:justify-between md:items-center space-y-4 md:space-y-0">

                

                <button type="button" id="SaveAccountSettings"
                    class="text-white bg-green hover:bg-green-700 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5">
                    Save Account
                </button>
            </div>
        </form>

    </section>

    <?php $__env->startPush('scripts'); ?>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const form = document.getElementById('SettingForm');
                const authBtn = document.getElementById('AuthenticateAccount');
                const saveBtn = document.getElementById('SaveAccountSettings');

                async function submitForm(url) {
                    const formData = new FormData(form);

                    // Show loading state (optional but good practice)
                    authBtn.disabled = true;
                    saveBtn.disabled = true;
                    const originalAuthText = authBtn.innerHTML;
                    const originalSaveText = saveBtn.innerHTML;

                    if (url.includes('authenticate')) {
                        authBtn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Processing...';
                    } else {
                        saveBtn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Saving...';
                    }

                    try {
                        const response = await fetch(url + `?host=<?php echo e(request('host')); ?>`, {
                            method: 'POST',
                            headers: {
                                'X-CSRF-TOKEN': document.querySelector('input[name="_token"]').value,
                                'Accept': 'application/json'
                            },
                            body: formData
                        });

                        const data = await response.json();

                        if (response.ok && (data.status || data.success)) {
                            // Success
                            // Using Shopify App Bridge Toast if available would be best, but simple alert for now
                            alert(data.message || 'Saved successfully');
                            window.location.reload();
                        } else {
                            alert(data.message || data.error || 'Error saving settings');
                        }
                    } catch (error) {
                        console.error('Error:', error);
                        alert('An error occurred. Please check console for details.');
                    } finally {
                        // Reset buttons
                        authBtn.disabled = false;
                        saveBtn.disabled = false;
                        authBtn.innerHTML = originalAuthText;
                        saveBtn.innerHTML = originalSaveText;
                    }
                }

                authBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    submitForm("<?php echo e(route('authenticateAndSave')); ?>");
                });

                saveBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    // Use updatesetting route for general updates
                    submitForm("<?php echo e(route('updatesetting')); ?>");
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\greenex-shopify-app\resources\views/settings.blade.php ENDPATH**/ ?>